/**
 * Automatically generated file. DO NOT MODIFY
 */
package org.videolan;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "org.videolan";
  public static final String BUILD_TYPE = "release";
}
